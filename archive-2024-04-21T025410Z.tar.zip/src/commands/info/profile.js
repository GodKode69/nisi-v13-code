const {
  MessageEmbed
} = require("discord.js");

module.exports = {
  name: "profile",
  category: "info",
  aliases: ["badge", "badges", "achievement", "pr"],
  cooldown: 5,
  usage: "invite",
  description: "Gives you an Invite link for this Bot",
  run: async (client, message, args, guildData, player, prefix) => {
    
      const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
      
      const bxby = user.id === "" ? true : false;
      let badges = "";

      const destroyer = user.id === "" ? true : false;
      let badges2 = "";
    
     const guild = await client.guilds.fetch("1215886037318893588"); 

      const sus = await guild.members.fetch(user.id).catch((e) => {
        
      if(user) badges = badges;
      else badges = "`No Badge Available`";
     });

     if(destroyer === true || user.id === "") badges = badges + `okay`;
    
      if(bxby === true || user.id === "") badges = badges + `okay`;
try{
      
const fyp = sus.roles.cache.has("1224239322979504169");
      if(fyp === true) badges = badges + `\n<:whitebotdeveloper:1224333913158320272>・**Developer**`;
   //  const pr = sus.roles.cache.has("959392690863210496");
    //  if(fr === true) badges = badges + `\n:teddy_friend: Friends`;
   //   const help = sus.roles.cache.has("948131708950159370");
   //   if(help === true) badges = badges + `\n:xeta_helper: Helper | Developer`;
const own = sus.roles.cache.has("1224239516559081563");
      if(own === true) badges = badges+`\n<:white_crown:1224334070956294196>・**Owner**`;
     // const bpart = sus.roles.cache.has("959093515781034016");
   //   if(bpart === true) badges = badges + `\n:xeta_partner: Partner`;
    //  const spons = sus.roles.cache.has("948131710279778336");
   //   if(spons === true) badges = badges + `\n:xeta_sponsor: Sponsor`;

      const han = sus.roles.cache.has("11224239537966813194");
      if(han === true) badges = badges + `\n<:white_admin:1224334125842825216>・**Admin**`;

    //  const gbug = sus.roles.cache.has("959094254901280769");
  //if(gbug === true) badges = badges + `\n:xeta_hunter_gold: Bug Hunter Prime`;

      const manager = sus.roles.cache.has("1224239556027482142");
      if(manager === true) badges = badges + `\n<:ModBadgeWhite:1224334202485604354>・**Mod**`;

     const aman = sus.roles.cache.has("1224239590768906260");
      if(aman === true) badges = badges + `\n<:staff_white:1224336054295986198>・**Support Team**`;

      const hundi = sus.roles.cache.has("1224239643420004373");
      if(hundi === true) badges = badges + `\n<:bug_hunter3:1224334345393668178>・**Bug Hunter**`;

      const supp = sus.roles.cache.has("1224239709333618738");
      if(supp === true) badges = badges + `\n<:SUPPORTER:1224241320919568498>・**Supporter**`;

      const fr = sus.roles.cache.has("1218945312484360232");
      if(fr === true) badges = badges + `\n<:fam:1224337313124057118>・**Family**`;



}catch(err){
if(badges) {
badges = "";
badges = badges;
}
else if(badges === "") badges = "`No Badge Available`";
}


      const pr = new MessageEmbed()
.setAuthor(`Profile For ${user.username}#${user.discriminator}`, client.user.displayAvatarURL({dynamic: true})) 
.setThumbnail(user.displayAvatarURL({dynamic: true}))
//.setTitle(`${user.username}'s Profile`)
.setColor(client.color)
.setTimestamp()
.setDescription(`
**BADGES** <a:badges:1224241928900444232>
${badges ? badges : "No Badge Available Join [Support Server](https://discord.com/invite/8unNYqWeFG) For badges"}`)
//.setTimestamp();
      message.channel.send({embeds: [pr]});
      
    }
  };